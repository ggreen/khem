package com.github.nylasolutions.khemapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KhemAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(KhemAppApplication.class, args);
	}
}
